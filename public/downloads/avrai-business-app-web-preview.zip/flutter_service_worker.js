'use strict';
const MANIFEST = 'flutter-app-manifest';
const TEMP = 'flutter-temp-cache';
const CACHE_NAME = 'flutter-app-cache';

const RESOURCES = {"flutter_bootstrap.js": "71fd07187a3258847d587eae75776610",
"version.json": "efbeaf4f0daf68dab3fbea26b0f0bd10",
"index.html": "a75f8282189ac28d7e9bc889a10943d5",
"/": "a75f8282189ac28d7e9bc889a10943d5",
"main.dart.js": "621bfddbe96d1cd8c2b1e3c6656855f1",
"flutter.js": "24bc71911b75b5f8135c949e27a2984e",
"favicon.png": "5dcef449791fa27946b3d35ad8803796",
"icons/Icon-192.png": "ac9a721a12bbc803b44f645561ecb1e1",
"icons/Icon-maskable-192.png": "c457ef57daa1d16f64b27b786ec2ea3c",
"icons/Icon-maskable-512.png": "301a7604d45b3e739efc881eb04896ea",
"icons/Icon-512.png": "96e752610906ba2a93c65f8abe1645f1",
"manifest.json": "8868d1184bb4ba00680955635a31b54e",
"assets/NOTICES": "85eeb47b5a5c3bd4ab3642d65bfd272a",
"assets/FontManifest.json": "7b2a36307916a9721811788013e65289",
"assets/AssetManifest.bin.json": "5f8f7c4a1849711ba9d8ba644277a2b5",
"assets/packages/nowplaying/assets/spotify.png": "476c48f395348709ce6e3665362a6464",
"assets/packages/nowplaying/assets/applemusic.png": "3cd841a0aecd64a9b221d7b9d4448f96",
"assets/packages/nowplaying/assets/listenapp.png": "c90cb48741e1f2f07bd314b854a721e4",
"assets/packages/flutter_inappwebview_web/assets/web/web_support.js": "509ae636cfdd93e49b5a6eaf0f06d79f",
"assets/packages/flutter_inappwebview/assets/t_rex_runner/t-rex.css": "5a8d0222407e388155d7d1395a75d5b9",
"assets/packages/flutter_inappwebview/assets/t_rex_runner/t-rex.html": "16911fcc170c8af1c5457940bd0bf055",
"assets/shaders/ink_sparkle.frag": "ecc85a2e95f5e9f53123dcaf8cb9b6ce",
"assets/shaders/stretch_effect.frag": "40d68efbbf360632f614c731219e95f0",
"assets/AssetManifest.bin": "8acc6d3ffdfa047ef7108e2cf3ec99f1",
"assets/fonts/MaterialIcons-Regular.otf": "96334a012a31230ac2c79c8ef069c993",
"downloads/business-node-agent/service_templates/install-macos-launch-agent.sh": "2ebcc654ae6be8af74225fe98e8aa445",
"downloads/business-node-agent/service_templates/SIGNING_AND_INSTALLERS.md": "eb20296c2d1ba72c3a4efb7099a7574c",
"downloads/business-node-agent/service_templates/com.avrai.business-node-agent.plist": "9813426665f6693174069366d071d8ce",
"downloads/business-node-agent/service_templates/install-windows-service.ps1": "0a878dd771d16419e4eb4e11cdb3e31a",
"downloads/business-node-agent/service_templates/avrai-business-node-agent.service": "b951f4e1a6f9fcd7006c01d80d727464",
"downloads/business-node-agent/service_templates/install-linux-systemd-user.sh": "3ed11e64c49387e958eac0bd00086b60",
"downloads/business-node-agent/artifacts/macos/avrai-business-node-agent-macos-arm64": "b4deb5b082ff3f6baf4426458954e63f",
"downloads/business-node-agent/download_manifest.json": "4aa0a6d923ede863648ca95f8f590cdf",
"downloads/business-node-agent/runtime_contracts/business_runtime_manifest.json": "9fbe72e67b29fb2a5aa3a37fe8295f00",
"downloads/business-node-agent/runtime_contracts/native_capability_policy_linux.json": "11edf08a90327dee81bf745db2979caa",
"downloads/business-node-agent/runtime_contracts/native_capability_policy_web.json": "3df42db10366e133e5cdadce05d0bd70",
"downloads/business-node-agent/runtime_contracts/business_desire.json": "b8cae070f9cfe05810a33cba80972805",
"downloads/business-node-agent/runtime_contracts/business_runtime_wiring.json": "9f005fac12bcbfb4b4cad33666c20347",
"downloads/business-node-agent/runtime_contracts/business_node_agent.json": "c221dff83aab05bdf370d9e47271dc79",
"downloads/business-node-agent/runtime_contracts/business_owner_claim.json": "f327d690dedd4ff849f42c99c7a81ec9",
"downloads/business-node-agent/runtime_contracts/native_capability_policy_macos.json": "49a540737481ea939955198141ede9b5",
"downloads/business-node-agent/runtime_contracts/business_place_scan.json": "5a2b8af6cc8dd7df6b561fd805e8f9c7",
"downloads/business-node-agent/runtime_contracts/native_capability_policy_windows.json": "fe443b896b59128609fb0c5409de98b2",
"downloads/business-node-agent/runtime_contracts/business_rundown.json": "3a21e7284caed21de27eebb0bc737aa6",
"downloads/business-node-agent/runtime_contracts/business_account.json": "8f2be37ed9e635e36b330cf30d6f83dd",
"downloads/business-node-agent/README.md": "432dab52652e48c8b394d2531bfc2119",
"canvaskit/skwasm.js": "8060d46e9a4901ca9991edd3a26be4f0",
"canvaskit/skwasm_heavy.js": "740d43a6b8240ef9e23eed8c48840da4",
"canvaskit/skwasm.js.symbols": "3a4aadf4e8141f284bd524976b1d6bdc",
"canvaskit/canvaskit.js.symbols": "a3c9f77715b642d0437d9c275caba91e",
"canvaskit/skwasm_heavy.js.symbols": "0755b4fb399918388d71b59ad390b055",
"canvaskit/skwasm.wasm": "7e5f3afdd3b0747a1fd4517cea239898",
"canvaskit/chromium/canvaskit.js.symbols": "e2d09f0e434bc118bf67dae526737d07",
"canvaskit/chromium/canvaskit.js": "a80c765aaa8af8645c9fb1aae53f9abf",
"canvaskit/chromium/canvaskit.wasm": "a726e3f75a84fcdf495a15817c63a35d",
"canvaskit/canvaskit.js": "8331fe38e66b3a898c4f37648aaf7ee2",
"canvaskit/canvaskit.wasm": "9b6a7830bf26959b200594729d73538e",
"canvaskit/skwasm_heavy.wasm": "b0be7910760d205ea4e011458df6ee01"};
// The application shell files that are downloaded before a service worker can
// start.
const CORE = ["main.dart.js",
"index.html",
"flutter_bootstrap.js",
"assets/AssetManifest.bin.json",
"assets/FontManifest.json"];

// During install, the TEMP cache is populated with the application shell files.
self.addEventListener("install", (event) => {
  self.skipWaiting();
  return event.waitUntil(
    caches.open(TEMP).then((cache) => {
      return cache.addAll(
        CORE.map((value) => new Request(value, {'cache': 'reload'})));
    })
  );
});
// During activate, the cache is populated with the temp files downloaded in
// install. If this service worker is upgrading from one with a saved
// MANIFEST, then use this to retain unchanged resource files.
self.addEventListener("activate", function(event) {
  return event.waitUntil(async function() {
    try {
      var contentCache = await caches.open(CACHE_NAME);
      var tempCache = await caches.open(TEMP);
      var manifestCache = await caches.open(MANIFEST);
      var manifest = await manifestCache.match('manifest');
      // When there is no prior manifest, clear the entire cache.
      if (!manifest) {
        await caches.delete(CACHE_NAME);
        contentCache = await caches.open(CACHE_NAME);
        for (var request of await tempCache.keys()) {
          var response = await tempCache.match(request);
          await contentCache.put(request, response);
        }
        await caches.delete(TEMP);
        // Save the manifest to make future upgrades efficient.
        await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
        // Claim client to enable caching on first launch
        self.clients.claim();
        return;
      }
      var oldManifest = await manifest.json();
      var origin = self.location.origin;
      for (var request of await contentCache.keys()) {
        var key = request.url.substring(origin.length + 1);
        if (key == "") {
          key = "/";
        }
        // If a resource from the old manifest is not in the new cache, or if
        // the MD5 sum has changed, delete it. Otherwise the resource is left
        // in the cache and can be reused by the new service worker.
        if (!RESOURCES[key] || RESOURCES[key] != oldManifest[key]) {
          await contentCache.delete(request);
        }
      }
      // Populate the cache with the app shell TEMP files, potentially overwriting
      // cache files preserved above.
      for (var request of await tempCache.keys()) {
        var response = await tempCache.match(request);
        await contentCache.put(request, response);
      }
      await caches.delete(TEMP);
      // Save the manifest to make future upgrades efficient.
      await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
      // Claim client to enable caching on first launch
      self.clients.claim();
      return;
    } catch (err) {
      // On an unhandled exception the state of the cache cannot be guaranteed.
      console.error('Failed to upgrade service worker: ' + err);
      await caches.delete(CACHE_NAME);
      await caches.delete(TEMP);
      await caches.delete(MANIFEST);
    }
  }());
});
// The fetch handler redirects requests for RESOURCE files to the service
// worker cache.
self.addEventListener("fetch", (event) => {
  if (event.request.method !== 'GET') {
    return;
  }
  var origin = self.location.origin;
  var key = event.request.url.substring(origin.length + 1);
  // Redirect URLs to the index.html
  if (key.indexOf('?v=') != -1) {
    key = key.split('?v=')[0];
  }
  if (event.request.url == origin || event.request.url.startsWith(origin + '/#') || key == '') {
    key = '/';
  }
  // If the URL is not the RESOURCE list then return to signal that the
  // browser should take over.
  if (!RESOURCES[key]) {
    return;
  }
  // If the URL is the index.html, perform an online-first request.
  if (key == '/') {
    return onlineFirst(event);
  }
  event.respondWith(caches.open(CACHE_NAME)
    .then((cache) =>  {
      return cache.match(event.request).then((response) => {
        // Either respond with the cached resource, or perform a fetch and
        // lazily populate the cache only if the resource was successfully fetched.
        return response || fetch(event.request).then((response) => {
          if (response && Boolean(response.ok)) {
            cache.put(event.request, response.clone());
          }
          return response;
        });
      })
    })
  );
});
self.addEventListener('message', (event) => {
  // SkipWaiting can be used to immediately activate a waiting service worker.
  // This will also require a page refresh triggered by the main worker.
  if (event.data === 'skipWaiting') {
    self.skipWaiting();
    return;
  }
  if (event.data === 'downloadOffline') {
    downloadOffline();
    return;
  }
});
// Download offline will check the RESOURCES for all files not in the cache
// and populate them.
async function downloadOffline() {
  var resources = [];
  var contentCache = await caches.open(CACHE_NAME);
  var currentContent = {};
  for (var request of await contentCache.keys()) {
    var key = request.url.substring(origin.length + 1);
    if (key == "") {
      key = "/";
    }
    currentContent[key] = true;
  }
  for (var resourceKey of Object.keys(RESOURCES)) {
    if (!currentContent[resourceKey]) {
      resources.push(resourceKey);
    }
  }
  return contentCache.addAll(resources);
}
// Attempt to download the resource online before falling back to
// the offline cache.
function onlineFirst(event) {
  return event.respondWith(
    fetch(event.request).then((response) => {
      return caches.open(CACHE_NAME).then((cache) => {
        cache.put(event.request, response.clone());
        return response;
      });
    }).catch((error) => {
      return caches.open(CACHE_NAME).then((cache) => {
        return cache.match(event.request).then((response) => {
          if (response != null) {
            return response;
          }
          throw error;
        });
      });
    })
  );
}
